@echo off
setlocal EnableExtensions EnableDelayedExpansion
chcp 65001 >nul

:: ============================================================================
:: Ferramenta de Suporte - WINDOWS 11
:: Ferramenta local para diagnostico, reparo e manutencao.
:: Nao abre sites, nao baixa arquivos e nao contem dados pessoais.
:: Execute como Administrador.
:: ============================================================================

title Ferramenta de Suporte - Windows 11
mode con: cols=112 lines=42
set "CORPADRAO=F"

set "VERSAO=3.3.1"
set "BASE=%~dp0"
set "LOGDIR=%BASE%Logs"
set "LOG=%LOGDIR%\SuperHelpDesk_%COMPUTERNAME%.log"
set "REPORTDIR=%USERPROFILE%\Desktop\SuperHelpDesk_Relatorios"
if not exist "%LOGDIR%" mkdir "%LOGDIR%" >nul 2>&1
if not exist "%REPORTDIR%" mkdir "%REPORTDIR%" >nul 2>&1

fltmc >nul 2>&1
if errorlevel 1 (
    echo.
    echo [AVISO] Execute como Administrador para usar todas as funcoes.
    echo.
    pause
)

call :LOG "Inicializacao - versao %VERSAO%"
goto COR

:COR
cls
color 07
echo ================================================================
echo                 PERSONALIZACAO DO PAINEL
echo ================================================================
echo.
echo  0 = Preto       8 = Cinza
 echo 1 = Azul        9 = Azul claro
 echo 2 = Verde       A = Verde claro
 echo 3 = Aqua        B = Aqua claro
 echo 4 = Vermelho    C = Vermelho claro
 echo 5 = Roxo        D = Roxo claro
 echo 6 = Amarelo     E = Amarelo claro
 echo 7 = Branco      F = Branco brilhante
echo.
echo ---------------------------------------------------------------
echo  O FUNDO PERMANECE PRETO.
echo  Digite somente UM codigo para a cor das letras.
echo  Exemplo: B = Aqua claro
 echo Padrao: B = Aqua claro
echo ---------------------------------------------------------------
echo.
set "cor="
set /p "cor=Escolha a cor das letras ou pressione ENTER para usar F: "
if not defined cor set "cor=F"
echo(%cor%| findstr /R /I "^[0-9A-F]$" >nul || (
    echo.
    echo [ERRO] Digite somente um valor entre 0-9 ou A-F.
    timeout /t 3 >nul
    goto COR
)
if /I "%cor%"=="0" (
    echo.
    echo [ERRO] Preto nao pode ser usado porque o fundo e preto.
    timeout /t 3 >nul
    goto COR
)
color 0%cor%
call :LOG "Cor das letras selecionada: %cor% - fundo fixo preto"
goto MENU

:MENU
call :INFO_CABECALHO
cls
echo.
echo  +=======================================================================================+
echo  ^|                           FERRAMENTA DE SUPORTE                                      ^|
echo  ^|                               WINDOWS 11                                              ^|
echo  +=======================================================================================+
echo.
echo   FERRAMENTA PARA USO DO TECNICO - EXECUTE COMO ADMINISTRADOR
echo.
echo  +---------------------------------------------------------------------------------------+
echo  ^| INFORMACOES DO DISPOSITIVO                                                            ^|
echo  +---------------------------------------------------------------------------------------+
echo   MAQUINA : %INFO_PC%
echo   SERIAL  : %INFO_SERIAL%
echo   LOGIN   : %INFO_LOGIN%
echo   LIGADA  : %INFO_UPTIME%
echo  +---------------------------------------------------------------------------------------+
echo.
echo   SISTEMA E WINDOWS
echo   [01] Agendar reparo completo do disco          [06] Reparar Windows: DISM + SFC
echo   [02] Diagnostico rapido do computador          [07] Reparar Microsoft Store e apps
echo   [03] Diagnosticar inicializacao e servicos     [08] Relatorio de falhas recentes
echo   [04] Limpar temporarios com seguranca          [09] Verificar disco C: online
echo   [05] Limpeza de componentes do Windows         [10] Otimizacao segura do Windows 11
echo.
echo   REDE E INTERNET
echo   [11] Diagnostico de DNS e gateway              [13] Reset da pilha de rede
echo   [12] Diagnostico de rede                       [14] Reset completo do Windows Update
echo   [15] Renovar IP e limpar DNS                   [16] Reparar driver e conexao de rede
echo   [17] Reparar sincronizacao do relogio
echo.
echo   HARDWARE E DRIVERS
echo   [18] Backup dos drivers instalados             [22] Memoria, CPU e processos pesados
echo   [19] Diagnostico de drivers                    [23] Reexaminar dispositivos
echo   [20] Energia e bateria                         [24] Verificar BitLocker
echo   [21] Dispositivos com erro                     [25] Reparar teclado que parou
echo   [26] Reparar audio e fone
echo.
echo   IMPRESSAO, INTERFACE E APLICATIVOS
echo   [27] Limpar fila de impressao                  [29] Reiniciar spooler de impressao
echo   [28] Limpar cache do Microsoft Teams           [30] Reparar barra de tarefas
echo.
echo   SUPORTE E ADMINISTRACAO
echo   [31] Abrir ferramentas administrativas         [34] Reiniciar o computador
echo   [32] Backup dos logs de eventos                [35] Verificar antivirus e firewall
echo   [33] Coletar pacote completo de suporte        [36] Atualizar politicas e gerar GPResult
echo   [37] Informacoes da maquina                    [38] Alterar cor das letras
echo   [39] Catalogo de problemas do Windows 11
echo.
echo   [00] Sair
echo  +=======================================================================================+
echo.
set "OP="
set /p "OP=Escolha uma opcao: "
if "%OP%"=="0" set "OP=00"
if "%OP%"=="1" set "OP=01"
if "%OP%"=="2" set "OP=02"
if "%OP%"=="3" set "OP=03"
if "%OP%"=="4" set "OP=04"
if "%OP%"=="5" set "OP=05"
if "%OP%"=="6" set "OP=06"
if "%OP%"=="7" set "OP=07"
if "%OP%"=="8" set "OP=08"
if "%OP%"=="9" set "OP=09"
if "%OP%"=="00" goto OP00
if "%OP%"=="01" goto OP01
if "%OP%"=="02" goto OP06
if "%OP%"=="03" goto OP10
if "%OP%"=="04" goto OP15
if "%OP%"=="05" goto OP16
if "%OP%"=="06" goto OP21
if "%OP%"=="07" goto OP22
if "%OP%"=="08" goto OP26
if "%OP%"=="09" goto OP28
if "%OP%"=="10" goto OP31
if "%OP%"=="11" goto OP08
if "%OP%"=="12" goto OP09
if "%OP%"=="13" goto OP18
if "%OP%"=="14" goto OP19
if "%OP%"=="15" goto OP20
if "%OP%"=="16" goto OP35
if "%OP%"=="17" goto OP39
if "%OP%"=="18" goto OP03
if "%OP%"=="19" goto OP07
if "%OP%"=="20" goto OP11
if "%OP%"=="21" goto OP12
if "%OP%"=="22" goto OP17
if "%OP%"=="23" goto OP25
if "%OP%"=="24" goto OP27
if "%OP%"=="25" goto OP37
if "%OP%"=="26" goto OP38
if "%OP%"=="27" goto OP13
if "%OP%"=="28" goto OP14
if "%OP%"=="29" goto OP24
if "%OP%"=="30" goto OP36
if "%OP%"=="31" goto OP02
if "%OP%"=="32" goto OP04
if "%OP%"=="33" goto OP05
if "%OP%"=="34" goto OP23
if "%OP%"=="35" goto OP29
if "%OP%"=="36" goto OP30
if "%OP%"=="37" goto OP33
if "%OP%"=="38" goto OP34
if "%OP%"=="39" goto CATALOGO
echo Opcao invalida.
timeout /t 2 >nul
goto MENU


:INFO_CABECALHO
set "INFO_PC=%COMPUTERNAME%"
set "INFO_SERIAL=Indisponivel"
set "INFO_LOGIN=%USERDOMAIN%\%USERNAME%"
set "INFO_UPTIME=Indisponivel"
set "_SHDPS=%TEMP%\shd_info_%RANDOM%.ps1"
>"%_SHDPS%" echo $ErrorActionPreference='SilentlyContinue'
>>"%_SHDPS%" echo $b=Get-CimInstance Win32_BIOS
>>"%_SHDPS%" echo if($b.SerialNumber){Write-Output ('SERIAL='+$b.SerialNumber.Trim())}
>>"%_SHDPS%" echo $c=Get-CimInstance Win32_ComputerSystem
>>"%_SHDPS%" echo if($c.UserName){Write-Output ('LOGIN='+$c.UserName)}
>>"%_SHDPS%" echo $o=Get-CimInstance Win32_OperatingSystem
>>"%_SHDPS%" echo if($o.LastBootUpTime){$t=(Get-Date)-$o.LastBootUpTime;Write-Output ('UPTIME='+[int]$t.TotalDays+'d '+$t.Hours+'h '+$t.Minutes+'min')}
for /f "tokens=1,* delims==" %%A in ('powershell.exe -NoLogo -NoProfile -NonInteractive -ExecutionPolicy Bypass -File "%_SHDPS%" 2^>nul') do (
    if /I "%%A"=="SERIAL" set "INFO_SERIAL=%%B"
    if /I "%%A"=="LOGIN" set "INFO_LOGIN=%%B"
    if /I "%%A"=="UPTIME" set "INFO_UPTIME=%%B"
)
del /q "%_SHDPS%" >nul 2>&1
exit /b

:HEADER
cls
echo.
echo =========================================================================================
echo   Ferramenta de Suporte - WINDOWS 11
echo =========================================================================================
echo   %~1
echo =========================================================================================
echo.
exit /b

:CONFIRM
set "RESP="
set /p "RESP=Confirma a execucao? (S/N): "
if /I "%RESP%"=="S" exit /b 0
exit /b 1

:LOG
>>"%LOG%" echo [%date% %time%] %~1
exit /b

:PAUSEMENU
echo.
echo Log: "%LOG%"
pause
goto MENU

:OP14
call :HEADER "[28] LIMPAR CACHE DO MICROSOFT TEAMS"
echo Esta rotina fecha o Teams e limpa SOMENTE os caches locais conhecidos.
echo Suporta o Novo Teams e o Teams Classico, quando presentes.
echo O Teams reconstruira o cache no proximo inicio.
echo.
echo ATENCAO: use esta rotina para problemas do cliente local.
call :CONFIRM || goto MENU
call :LOG "Limpeza de cache do Microsoft Teams"
echo.
echo [1/4] Encerrando processos do Teams...
taskkill /F /IM ms-teams.exe >nul 2>&1
taskkill /F /IM Teams.exe >nul 2>&1
timeout /t 2 >nul

echo [2/4] Verificando Novo Teams...
set "NEWTEAMS=%LOCALAPPDATA%\Packages\MSTeams_8wekyb3d8bbwe\LocalCache\Microsoft\MSTeams"
if exist "%NEWTEAMS%" (
    powershell -NoProfile -Command "Get-ChildItem -LiteralPath $env:LOCALAPPDATA'\Packages\MSTeams_8wekyb3d8bbwe\LocalCache\Microsoft\MSTeams' -Force -ErrorAction SilentlyContinue | Remove-Item -Recurse -Force -ErrorAction SilentlyContinue"
    echo       Cache do Novo Teams limpo.
) else (
    echo       Cache do Novo Teams nao encontrado para este usuario.
)

echo [3/4] Verificando Teams Classico...
set "OLDTEAMS=%APPDATA%\Microsoft\Teams"
if exist "%OLDTEAMS%" (
    powershell -NoProfile -Command "Get-ChildItem -LiteralPath $env:APPDATA'\Microsoft\Teams' -Force -ErrorAction SilentlyContinue | Remove-Item -Recurse -Force -ErrorAction SilentlyContinue"
    echo       Cache do Teams Classico limpo.
) else (
    echo       Cache do Teams Classico nao encontrado para este usuario.
)

echo [4/4] Finalizado.
echo.
echo Abra o Microsoft Teams novamente. O primeiro inicio pode demorar mais.
call :LOG "Limpeza de cache do Microsoft Teams concluida"
goto PAUSEMENU

:OP35
call :HEADER "[16] REPARAR DRIVER E CONEXAO DE REDE"
echo Reinicia adaptadores ativos, reexamina dispositivos e redefine a pilha de rede.
echo A conexao pode cair durante a execucao. Reinicie o computador ao final.
echo.
call :CONFIRM || goto MENU
call :LOG "Reparo de driver e conexao de rede"
echo [1/6] Reexaminando dispositivos...
pnputil /scan-devices
echo [2/6] Reiniciando adaptadores de rede ativos...
powershell.exe -NoLogo -NoProfile -NonInteractive -Command "Get-NetAdapter -ErrorAction SilentlyContinue | Where-Object Status -ne 'Disabled' | Restart-NetAdapter -Confirm:$false -ErrorAction Continue"
echo [3/6] Redefinindo Winsock...
netsh winsock reset
echo [4/6] Redefinindo TCP/IP...
netsh int ip reset
echo [5/6] Limpando DNS e renovando IP...
ipconfig /flushdns
ipconfig /release
ipconfig /renew
echo [6/6] Reiniciando servicos de rede...
for %%S in (Dhcp Dnscache NlaSvc netprofm WlanSvc) do net start %%S >nul 2>&1
echo.
echo Reparo concluido. Reinicie o computador para aplicar tudo.
goto PAUSEMENU

:OP36
call :HEADER "[30] REPARAR BARRA DE TAREFAS"
echo Reinicia o Windows Explorer e limpa o cache local de icones da bandeja.
echo As janelas do Explorador de Arquivos podem fechar.
echo.
call :CONFIRM || goto MENU
call :LOG "Reparo da barra de tarefas"
taskkill /F /IM explorer.exe >nul 2>&1
timeout /t 2 >nul
powershell.exe -NoLogo -NoProfile -NonInteractive -Command "Remove-ItemProperty -Path 'HKCU:\Software\Classes\Local Settings\Software\Microsoft\Windows\CurrentVersion\TrayNotify' -Name IconStreams,PastIconsStream -ErrorAction SilentlyContinue"
start "" explorer.exe
timeout /t 3 >nul
if not exist "%SystemRoot%\explorer.exe" echo [ERRO] Explorer nao encontrado.
echo Barra de tarefas reiniciada.
echo Se continuar ausente, execute a opcao 21 para reparar o Windows.
goto PAUSEMENU

:OP37
call :HEADER "[25] REPARAR TECLADO QUE PAROU"
echo Reativa servicos de entrada e solicita nova deteccao dos dispositivos.
echo.
call :CONFIRM || goto MENU
call :LOG "Reparo de teclado"
echo [1/4] Iniciando servicos de entrada...
sc config hidserv start= demand >nul 2>&1
net start hidserv >nul 2>&1
sc config TabletInputService start= demand >nul 2>&1
net start TabletInputService >nul 2>&1
echo [2/4] Reexaminando dispositivos...
pnputil /scan-devices
echo [3/4] Verificando dispositivos de teclado...
powershell.exe -NoLogo -NoProfile -NonInteractive -Command "Get-PnpDevice -Class Keyboard -ErrorAction SilentlyContinue | Format-Table Status,FriendlyName,InstanceId -AutoSize"
echo [4/4] Abrindo o Gerenciador de Dispositivos...
start "" devmgmt.msc
echo.
echo Se o teclado interno nao aparecer, verifique driver OEM, BIOS e conexao fisica.
goto PAUSEMENU

:OP38
call :HEADER "[26] REPARAR AUDIO E FONE"
echo Reinicia os servicos de audio e reexamina os dispositivos de som.
echo.
call :CONFIRM || goto MENU
call :LOG "Reparo de audio e fone"
echo [1/4] Reiniciando servicos de audio...
net stop AudioEndpointBuilder /y >nul 2>&1
net stop Audiosrv /y >nul 2>&1
net start AudioEndpointBuilder >nul 2>&1
net start Audiosrv >nul 2>&1
echo [2/4] Reexaminando dispositivos...
pnputil /scan-devices
echo [3/4] Listando dispositivos de audio...
powershell.exe -NoLogo -NoProfile -NonInteractive -Command "Get-PnpDevice -Class AudioEndpoint,Media -ErrorAction SilentlyContinue | Format-Table Status,Class,FriendlyName -AutoSize"
echo [4/4] Abrindo selecao de dispositivo de reproducao...
start "" mmsys.cpl
echo.
echo Selecione o fone correto como dispositivo padrao e teste o audio.
goto PAUSEMENU

:OP39
call :HEADER "[17] REPARAR SINCRONIZACAO DO RELOGIO"
echo Reinicia e reconfigura o servico Windows Time sem alterar o fuso horario.
echo.
call :CONFIRM || goto MENU
call :LOG "Reparo da sincronizacao do relogio"
sc config w32time start= auto
net stop w32time >nul 2>&1
net start w32time
w32tm /config /syncfromflags:manual /manualpeerlist:"time.windows.com,0x9" /update
w32tm /resync /rediscover
echo.
w32tm /query /status
echo.
echo Se falhar em rede corporativa, valide DNS, firewall e liberacao NTP UDP 123.
goto PAUSEMENU

:OP34
goto COR

:OP33
call :HEADER "[37] INFORMACOES DA MAQUINA"
echo Coletando informacoes locais...
echo.
echo   NOME DA MAQUINA : %COMPUTERNAME%
echo   LOGIN CMD       : %USERDOMAIN%\%USERNAME%
echo.
echo   SERIAL:
powershell.exe -NoLogo -NoProfile -NonInteractive -Command "try{$s=(Get-CimInstance Win32_BIOS -ErrorAction Stop).SerialNumber;if([string]::IsNullOrWhiteSpace($s)){Write-Output 'Indisponivel'}else{Write-Output $s.Trim()}}catch{Write-Output 'Indisponivel'}"
echo.
echo   USUARIO LOGADO:
powershell.exe -NoLogo -NoProfile -NonInteractive -Command "try{$u=(Get-CimInstance Win32_ComputerSystem -ErrorAction Stop).UserName;if([string]::IsNullOrWhiteSpace($u)){Write-Output ($env:USERDOMAIN+'\'+$env:USERNAME)}else{Write-Output $u}}catch{Write-Output ($env:USERDOMAIN+'\'+$env:USERNAME)}"
echo.
echo   TEMPO LIGADA:
powershell.exe -NoLogo -NoProfile -NonInteractive -Command "try{$os=Get-CimInstance Win32_OperatingSystem -ErrorAction Stop;$t=(Get-Date)-$os.LastBootUpTime;Write-Output (('{0} dias, {1} horas e {2} minutos' -f [int]$t.TotalDays,$t.Hours,$t.Minutes))}catch{Write-Output 'Indisponivel'}"
echo.
call :LOG "Consulta manual de informacoes da maquina"
goto PAUSEMENU

:CATALOGO
cls
echo.
echo  +=======================================================================================+
echo  ^|              CATALOGO - PROBLEMAS ADICIONAIS DO WINDOWS 11                         ^|
echo  +=======================================================================================+
echo   Este catalogo mostra apenas problemas que NAO possuem uma solucao equivalente
echo   no menu principal.
echo.
echo   [01] Bluetooth nao conecta                   [07] Tela azul - BSOD
 echo  [02] Windows nao inicia                      [08] PIN ou Windows Hello nao funciona
 echo  [03] Tela preta depois do login              [09] Disco cheio ou uso em 100%%
 echo  [04] Menu Iniciar ou Pesquisa travada        [10] VPN ou acesso remoto nao conecta
 echo  [05] Explorador de Arquivos travando         [11] PC nao desliga ou reinicia sozinho
 echo  [06] Aplicativo fecha ou nao abre            [12] PC nao volta da suspensao
 echo.
echo   [00] Voltar ao menu principal
echo  +=======================================================================================+
set "FIX="
set /p "FIX=Escolha o problema: "
if "%FIX%"=="0" set "FIX=00"
if "%FIX%"=="1" set "FIX=01"
if "%FIX%"=="2" set "FIX=02"
if "%FIX%"=="3" set "FIX=03"
if "%FIX%"=="4" set "FIX=04"
if "%FIX%"=="5" set "FIX=05"
if "%FIX%"=="6" set "FIX=06"
if "%FIX%"=="7" set "FIX=07"
if "%FIX%"=="8" set "FIX=08"
if "%FIX%"=="9" set "FIX=09"
if "%FIX%"=="00" goto MENU
for %%N in (01 02 03 04 05 06 07 08 09 10 11 12) do if "%FIX%"=="%%N" goto FIX%%N
echo Opcao invalida.
timeout /t 2 >nul
goto CATALOGO

:FIX01
call :HEADER "BLUETOOTH NAO CONECTA"
echo Reinicia o servico Bluetooth e reexamina os dispositivos.
call :CONFIRM || goto CATALOGO
sc config bthserv start= demand >nul 2>&1
net stop bthserv >nul 2>&1
net start bthserv
pnputil /scan-devices
echo PASSOS: Configuracoes, Bluetooth e dispositivos, remova o equipamento e emparelhe novamente.
goto PAUSEFIX

:FIX02
call :HEADER "WINDOWS NAO INICIA"
echo Esta correcao exige o Ambiente de Recuperacao do Windows.
echo 1. Na tela de login, segure SHIFT e clique em Reiniciar.
echo 2. Entre em Solucao de Problemas, Opcoes Avancadas, Reparo de Inicializacao.
echo 3. Se falhar, tente Desinstalar atualizacoes e remova a ultima atualizacao de qualidade.
echo 4. Depois tente Restauracao do Sistema.
echo 5. Use Modo de Seguranca para remover driver ou software instalado antes da falha.
echo Nao execute comandos de BCD sem confirmar o modo UEFI, a particao EFI e o BitLocker.
goto PAUSEFIX

:FIX03
call :HEADER "TELA PRETA DEPOIS DO LOGIN"
echo Tenta recuperar a interface grafica sem reiniciar o computador.
taskkill /F /IM explorer.exe >nul 2>&1
start "" explorer.exe
echo PASSOS: pressione Win+Ctrl+Shift+B para reiniciar o driver grafico.
echo Depois abra o Gerenciador de Dispositivos e reverta ou atualize o driver de video.
start "" devmgmt.msc
goto PAUSEFIX

:FIX04
call :HEADER "MENU INICIAR OU PESQUISA TRAVADA"
echo Reinicia Explorer e o processo de pesquisa do usuario.
call :CONFIRM || goto CATALOGO
taskkill /F /IM SearchHost.exe >nul 2>&1
taskkill /F /IM StartMenuExperienceHost.exe >nul 2>&1
taskkill /F /IM explorer.exe >nul 2>&1
start "" explorer.exe
echo Os processos do Menu Iniciar e Pesquisa serao recriados automaticamente.
goto PAUSEFIX

:FIX05
call :HEADER "EXPLORADOR DE ARQUIVOS TRAVANDO"
echo Reinicia Explorer e limpa apenas o historico de arquivos recentes.
call :CONFIRM || goto CATALOGO
taskkill /F /IM explorer.exe >nul 2>&1
del /f /q "%APPDATA%\Microsoft\Windows\Recent\AutomaticDestinations\*" >nul 2>&1
start "" explorer.exe
sfc /verifyonly
goto PAUSEFIX

:FIX06
call :HEADER "APLICATIVO FECHA OU NAO ABRE"
echo 1. Configuracoes, Aplicativos, Aplicativos instalados.
echo 2. Abra Opcoes avancadas do aplicativo e tente Reparar.
echo 3. Se falhar, use Redefinir. Isso pode apagar configuracoes locais do app.
echo 4. Verifique o Visualizador de Eventos em Logs do Windows, Aplicativo.
echo 5. Teste com inicializacao limpa: msconfig, Servicos, ocultar servicos Microsoft.
start "" eventvwr.msc
goto PAUSEFIX

:FIX07
call :HEADER "TELA AZUL - BSOD"
echo Coleta os eventos criticos recentes e lista arquivos de despejo.
powershell.exe -NoLogo -NoProfile -NonInteractive -Command "Get-WinEvent -FilterHashtable @{LogName='System';Level=1,2;StartTime=(Get-Date).AddDays(-7)} -ErrorAction SilentlyContinue | Select-Object -First 30 TimeCreated,ProviderName,Id,Message | Format-List"
dir /b "%SystemRoot%\Minidump\*.dmp" 2>nul
echo PASSOS: anote o codigo STOP, reverta driver ou atualizacao recente e rode a opcao de reparo DISM + SFC.
echo Se houver dump, analise com WinDbg em ambiente tecnico autorizado.
goto PAUSEFIX

:FIX08
call :HEADER "PIN OU WINDOWS HELLO NAO FUNCIONA"
echo 1. Na tela de entrada, selecione Opcoes de entrada e tente a senha da conta.
echo 2. Depois abra Configuracoes, Contas, Opcoes de entrada, PIN, Esqueci meu PIN.
echo 3. Confirme Internet, data e hora e o acesso aos servicos corporativos.
echo 4. Em dispositivo corporativo, valide Entra ID, Intune e politica do Windows Hello.
echo 5. Nao exclua manualmente a pasta NGC sem avaliar BitLocker, perfil e politica corporativa.
start "" ms-settings:signinoptions
goto PAUSEFIX

:FIX09
call :HEADER "DISCO CHEIO OU USO EM 100 POR CENTO"
echo Mostra espaco livre e processos com maior leitura e gravacao.
powershell.exe -NoLogo -NoProfile -NonInteractive -Command "Get-Volume | Where-Object DriveLetter | Select-Object DriveLetter,@{N='LivreGB';E={[math]::Round($_.SizeRemaining/1GB,1)}},@{N='TotalGB';E={[math]::Round($_.Size/1GB,1)}} | Format-Table -AutoSize"
cleanmgr.exe
echo PASSOS: Configuracoes, Sistema, Armazenamento, Arquivos temporarios.
echo Nao apague WinSxS, Installer ou perfis manualmente.
goto PAUSEFIX

:FIX10
call :HEADER "VPN OU ACESSO REMOTO NAO CONECTA"
echo Coleta estado de rede, adaptadores e rotas sem alterar a VPN.
ipconfig /all
route print -4
netsh interface show interface
sc query RasMan
sc query IKEEXT
echo PASSOS: confirme Internet, horario, MFA, certificado e credenciais.
echo Em VPN corporativa, valide cliente, gateway, firewall, DNS interno e politica do fornecedor.
goto PAUSEFIX

:FIX11
call :HEADER "PC NAO DESLIGA OU REINICIA SOZINHO"
echo Mostra solicitacoes que impedem suspensao ou desligamento.
powercfg /requests
powercfg /lastwake
echo PASSOS: feche apps, desconecte USBs e teste shutdown /s /f /t 0.
echo ATENCAO: /f fecha aplicativos sem salvar. Execute manualmente somente depois de salvar tudo.
goto PAUSEFIX

:FIX12
call :HEADER "PC NAO VOLTA DA SUSPENSAO"
echo Mostra estados suportados e o ultimo dispositivo que acordou a maquina.
powercfg /a
powercfg /lastwake
powercfg /devicequery wake_armed
echo PASSOS: atualize BIOS, chipset e video; teste desmarcar Inicializacao rapida no Painel de Energia.
goto PAUSEFIX

:PAUSEFIX
echo.
echo Pressione qualquer tecla para voltar ao catalogo.
pause >nul
goto CATALOGO

:OP00
call :LOG "Encerramento"
exit /b 0

:OP06
call :HEADER "[02] DIAGNOSTICO RAPIDO"
call :LOG "Diagnostico rapido"
echo Nome: %COMPUTERNAME%    Usuario: %USERNAME%
echo.
systeminfo | findstr /B /C:"OS Name" /C:"OS Version" /C:"System Model" /C:"System Type" /C:"Total Physical Memory"
echo.
echo --- DISCOS ---
powershell -NoProfile -Command "Get-CimInstance Win32_LogicalDisk -Filter 'DriveType=3' | Select DeviceID,@{N='TotalGB';E={[math]::Round($_.Size/1GB,1)}},@{N='LivreGB';E={[math]::Round($_.FreeSpace/1GB,1)}},@{N='Livre%%';E={if($_.Size){[math]::Round(100*$_.FreeSpace/$_.Size,0)}else{0}}} | Format-Table -AutoSize"
echo --- REINICIO PENDENTE ---
powershell -NoProfile -Command "$p=(Test-Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Component Based Servicing\RebootPending') -or (Test-Path 'HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\WindowsUpdate\Auto Update\RebootRequired'); if($p){'SIM'}else{'NAO'}"
goto PAUSEMENU

:OP21
call :HEADER "[06] REPARO DO WINDOWS - DISM E SFC"
echo Executa CheckHealth, ScanHealth, RestoreHealth e SFC.
echo O RestoreHealth pode usar a origem de reparo configurada pela organizacao.
call :CONFIRM || goto MENU
call :LOG "DISM e SFC"
DISM /Online /Cleanup-Image /CheckHealth
DISM /Online /Cleanup-Image /ScanHealth
DISM /Online /Cleanup-Image /RestoreHealth
sfc /scannow
goto PAUSEMENU

:OP28
call :HEADER "[09] VERIFICACAO ONLINE DO DISCO C:"
call :LOG "CHKDSK scan"
chkdsk C: /scan
goto PAUSEMENU

:OP01
call :HEADER "[01] AGENDAR REPARO COMPLETO DO DISCO"
echo Pode exigir reinicializacao e levar bastante tempo.
call :CONFIRM || goto MENU
call :LOG "CHKDSK C: /F agendado"
echo S|chkdsk C: /F
goto PAUSEMENU

:OP15
call :HEADER "[04] LIMPEZA SEGURA DE TEMPORARIOS"
call :CONFIRM || goto MENU
call :LOG "Limpeza de temporarios"
powershell -NoProfile -Command "$paths=@($env:TEMP,($env:WINDIR+'\Temp')); foreach($p in $paths){if(Test-Path $p){Get-ChildItem -LiteralPath $p -Force -ErrorAction SilentlyContinue | Remove-Item -Recurse -Force -ErrorAction SilentlyContinue}}"
echo Limpeza concluida. Arquivos em uso foram preservados.
goto PAUSEMENU

:OP16
call :HEADER "[05] LIMPEZA DE COMPONENTES DO WINDOWS"
call :CONFIRM || goto MENU
call :LOG "DISM StartComponentCleanup"
DISM /Online /Cleanup-Image /StartComponentCleanup
goto PAUSEMENU

:OP19
call :HEADER "[14] RESET COMPLETO DO WINDOWS UPDATE"
echo Recria os caches SoftwareDistribution e Catroot2.
call :CONFIRM || goto MENU
call :LOG "Reset Windows Update"
for %%S in (bits wuauserv cryptsvc msiserver) do net stop %%S /y >nul 2>&1
if exist "%SystemRoot%\SoftwareDistribution.old" rd /s /q "%SystemRoot%\SoftwareDistribution.old"
if exist "%SystemRoot%\System32\catroot2.old" rd /s /q "%SystemRoot%\System32\catroot2.old"
if exist "%SystemRoot%\SoftwareDistribution" ren "%SystemRoot%\SoftwareDistribution" SoftwareDistribution.old
if exist "%SystemRoot%\System32\catroot2" ren "%SystemRoot%\System32\catroot2" catroot2.old
for %%S in (cryptsvc bits wuauserv msiserver) do net start %%S >nul 2>&1
echo Reset concluido.
goto PAUSEMENU

:OP09
call :HEADER "[12] DIAGNOSTICO DE REDE"
call :LOG "Diagnostico de rede"
ipconfig /all
echo.
echo --- ROTAS ---
route print -4
echo.
echo --- ADAPTADORES ---
netsh interface show interface
goto PAUSEMENU

:OP18
call :HEADER "[13] RESET DA PILHA DE REDE"
echo Reseta Winsock e TCP/IP. Reinicie o computador ao final.
call :CONFIRM || goto MENU
call :LOG "Reset Winsock e TCP/IP"
netsh winsock reset
netsh int ip reset
ipconfig /flushdns
goto PAUSEMENU

:OP20
call :HEADER "[15] RENOVAR IP E LIMPAR DNS"
call :LOG "Release Renew FlushDNS"
ipconfig /release
ipconfig /flushdns
ipconfig /renew
goto PAUSEMENU

:OP08
call :HEADER "[11] DIAGNOSTICO DE DNS E GATEWAY"
call :LOG "Diagnostico DNS e gateway"
powershell -NoProfile -Command "$g=(Get-NetRoute -DestinationPrefix '0.0.0.0/0' -ErrorAction SilentlyContinue | Sort RouteMetric | Select -First 1 -Expand NextHop); 'Gateway: '+$g; if($g){Test-Connection $g -Count 2}; 'DNS configurado:'; Get-DnsClientServerAddress -AddressFamily IPv4 | Where ServerAddresses | Format-Table InterfaceAlias,ServerAddresses -AutoSize; 'Teste DNS local:'; Resolve-DnsName $env:COMPUTERNAME -ErrorAction SilentlyContinue"
goto PAUSEMENU

:OP07
call :HEADER "[19] DIAGNOSTICO DE DRIVERS"
call :LOG "Inventario de drivers"
pnputil /enum-drivers
echo.
driverquery /v /fo table
goto PAUSEMENU

:OP25
call :HEADER "[23] REEXAMINAR DISPOSITIVOS"
call :LOG "PNPUtil scan-devices"
pnputil /scan-devices
goto PAUSEMENU

:OP03
call :HEADER "[18] BACKUP DOS DRIVERS"
set "DRIVERBACKUP=%REPORTDIR%\Drivers_%COMPUTERNAME%"
if not exist "%DRIVERBACKUP%" mkdir "%DRIVERBACKUP%"
call :LOG "Backup de drivers em %DRIVERBACKUP%"
pnputil /export-driver * "%DRIVERBACKUP%"
echo Backup salvo em: "%DRIVERBACKUP%"
goto PAUSEMENU

:OP12
call :HEADER "[21] DISPOSITIVOS COM ERRO"
call :LOG "Dispositivos PnP com erro"
powershell -NoProfile -Command "Get-CimInstance Win32_PnPEntity | Where-Object {$_.ConfigManagerErrorCode -ne 0} | Select Name,PNPDeviceID,ConfigManagerErrorCode | Format-Table -Wrap -AutoSize"
goto PAUSEMENU

:OP24
call :HEADER "[29] REINICIAR SPOOLER DE IMPRESSAO"
call :LOG "Reinicio do spooler"
net stop spooler
net start spooler
goto PAUSEMENU

:OP13
call :HEADER "[27] LIMPAR FILA DE IMPRESSAO"
call :CONFIRM || goto MENU
call :LOG "Limpeza da fila de impressao"
net stop spooler >nul 2>&1
del /f /q "%SystemRoot%\System32\spool\PRINTERS\*" >nul 2>&1
net start spooler >nul 2>&1
echo Fila limpa e servico iniciado.
goto PAUSEMENU

:OP22
call :HEADER "[07] REPARAR MICROSOFT STORE E APPS"
echo Limpa o cache da Store e registra novamente os apps instalados.
call :CONFIRM || goto MENU
call :LOG "Reparo Microsoft Store e apps"
start /wait wsreset.exe
powershell -NoProfile -ExecutionPolicy Bypass -Command "Get-AppxPackage -AllUsers | ForEach-Object {if(Test-Path ($_.InstallLocation+'\AppXManifest.xml')){Add-AppxPackage -DisableDevelopmentMode -Register ($_.InstallLocation+'\AppXManifest.xml') -ErrorAction SilentlyContinue}}"
goto PAUSEMENU

:OP27
call :HEADER "[24] STATUS DO BITLOCKER"
call :LOG "Status BitLocker"
manage-bde -status
goto PAUSEMENU

:OP29
call :HEADER "[35] ANTIVIRUS E FIREWALL"
call :LOG "Status antivirus e firewall"
powershell -NoProfile -Command "Get-CimInstance -Namespace root/SecurityCenter2 -Class AntivirusProduct -ErrorAction SilentlyContinue | Select displayName,pathToSignedProductExe,productState | Format-Table -AutoSize"
netsh advfirewall show allprofiles state
goto PAUSEMENU

:OP30
call :HEADER "[36] POLITICAS E GPRESULT"
call :LOG "GPUpdate e GPResult"
gpupdate /force
gpresult /H "%REPORTDIR%\GPResult_%COMPUTERNAME%.html" /F
gpresult /R
echo Relatorio salvo em: "%REPORTDIR%"
goto PAUSEMENU

:OP10
call :HEADER "[03] INICIALIZACAO E SERVICOS"
call :LOG "Servicos automaticos parados"
echo --- SERVICOS AUTOMATICOS PARADOS ---
powershell -NoProfile -Command "Get-CimInstance Win32_Service | Where-Object {$_.StartMode -eq 'Auto' -and $_.State -ne 'Running'} | Select Name,DisplayName,State,StartMode,ExitCode | Format-Table -AutoSize"
echo --- INICIALIZACAO ---
powershell -NoProfile -Command "Get-CimInstance Win32_StartupCommand | Select Name,Command,Location | Format-Table -Wrap -AutoSize"
goto PAUSEMENU

:OP11
call :HEADER "[20] ENERGIA E BATERIA"
call :LOG "Relatorios de energia"
powercfg /getactivescheme
powercfg /batteryreport /output "%REPORTDIR%\Battery_%COMPUTERNAME%.html" >nul 2>&1
powercfg /energy /duration 30 /output "%REPORTDIR%\Energy_%COMPUTERNAME%.html"
echo Relatorios salvos em: "%REPORTDIR%"
goto PAUSEMENU

:OP17
call :HEADER "[22] MEMORIA, CPU E PROCESSOS PESADOS"
call :LOG "Uso de recursos"
powershell -NoProfile -Command "$os=Get-CimInstance Win32_OperatingSystem; $used=[math]::Round(($os.TotalVisibleMemorySize-$os.FreePhysicalMemory)/1MB,2); $total=[math]::Round($os.TotalVisibleMemorySize/1MB,2); 'RAM usada: '+$used+' GB de '+$total+' GB'; 'Processos por memoria:'; Get-Process | Sort WorkingSet64 -Descending | Select -First 15 Name,Id,@{N='RAM_MB';E={[math]::Round($_.WorkingSet64/1MB,0)}},CPU | Format-Table -AutoSize"
goto PAUSEMENU

:OP04
call :HEADER "[32] BACKUP DOS LOGS DE EVENTOS"
set "EV=%REPORTDIR%\Eventos_%COMPUTERNAME%"
if not exist "%EV%" mkdir "%EV%"
call :LOG "Backup dos eventos"
for %%L in (Application System Setup) do wevtutil epl %%L "%EV%\%%L.evtx" /ow:true
echo Backup salvo em: "%EV%"
goto PAUSEMENU

:OP05
call :HEADER "[33] COLETA COMPLETA DE SUPORTE"
call :CONFIRM || goto MENU
set "PKG=%REPORTDIR%\Coleta_%COMPUTERNAME%_%RANDOM%"
mkdir "%PKG%" >nul 2>&1
call :LOG "Coleta completa em %PKG%"
systeminfo >"%PKG%\systeminfo.txt"
ipconfig /all >"%PKG%\ipconfig.txt"
route print >"%PKG%\rotas.txt"
driverquery /v /fo csv >"%PKG%\drivers.csv"
tasklist /v /fo csv >"%PKG%\processos.csv"
sc query type= service state= all >"%PKG%\servicos.txt"
gpresult /R >"%PKG%\gpresult.txt" 2>&1
pnputil /enum-devices /problem >"%PKG%\dispositivos_com_erro.txt" 2>&1
powershell -NoProfile -Command "Get-ComputerInfo | Out-File -Width 240 -Encoding utf8 '%PKG%\computerinfo.txt'; Compress-Archive -Path '%PKG%\*' -DestinationPath '%PKG%.zip' -Force"
echo Pacote criado: "%PKG%.zip"
goto PAUSEMENU

:OP31
call :HEADER "[10] OTIMIZACAO SEGURA DO WINDOWS 11"
echo Executa limpeza de temporarios, componentes, cache DNS, otimizacao de unidades
echo e verificacao de arquivos. Nao desativa seguranca, telemetria, servicos ou recursos.
call :CONFIRM || goto MENU
call :LOG "Otimizacao segura"
powershell -NoProfile -Command "$paths=@($env:TEMP,($env:WINDIR+'\Temp')); foreach($p in $paths){if(Test-Path $p){Get-ChildItem -LiteralPath $p -Force -ErrorAction SilentlyContinue | Remove-Item -Recurse -Force -ErrorAction SilentlyContinue}}"
DISM /Online /Cleanup-Image /StartComponentCleanup
ipconfig /flushdns
powershell -NoProfile -Command "Get-Volume | Where-Object {$_.DriveType -eq 'Fixed' -and $_.DriveLetter} | ForEach-Object {Optimize-Volume -DriveLetter $_.DriveLetter -Verbose -ErrorAction Continue}"
sfc /verifyonly
echo Otimizacao concluida.
goto PAUSEMENU

:OP02
call :HEADER "[31] FERRAMENTAS ADMINISTRATIVAS"
echo  [1] Gerenciador de Dispositivos
 echo [2] Visualizador de Eventos
 echo [3] Gerenciamento de Disco
 echo [4] Servicos
 echo [5] Informacoes do Sistema
 echo [6] Monitor de Confiabilidade
 echo [7] Configuracao do Sistema
 echo [0] Voltar
set "T="
set /p "T=Escolha: "
if "%T%"=="1" start "" devmgmt.msc
if "%T%"=="2" start "" eventvwr.msc
if "%T%"=="3" start "" diskmgmt.msc
if "%T%"=="4" start "" services.msc
if "%T%"=="5" start "" msinfo32.exe
if "%T%"=="6" start "" perfmon.exe /rel
if "%T%"=="7" start "" msconfig.exe
goto MENU

:OP26
call :HEADER "[08] FALHAS RECENTES"
call :LOG "Falhas recentes"
powershell -NoProfile -Command "$since=(Get-Date).AddDays(-7); Get-WinEvent -FilterHashtable @{LogName='System','Application';Level=1,2;StartTime=$since} -ErrorAction SilentlyContinue | Select -First 80 TimeCreated,LogName,ProviderName,Id,LevelDisplayName,Message | Format-List"
goto PAUSEMENU

:OP23
call :HEADER "[34] REINICIAR O COMPUTADOR"
echo Salve todo o trabalho antes de continuar.
call :CONFIRM || goto MENU
call :LOG "Reinicio solicitado"
shutdown /r /t 15 /c "Reinicio solicitado pelo Ferramenta de Suporte"
exit /b 0


:ERRO_FATAL
echo.
echo ================================================================
echo [ERRO] O script chegou a um ponto inesperado.
echo O CMD sera mantido aberto para diagnostico.
echo ================================================================
pause
goto MENU
